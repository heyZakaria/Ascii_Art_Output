package main

import (
	"fmt"
	"os"
	"strings"

	output "output/funcs"
)

func main() {
	if len(os.Args) == 1 {
		fmt.Println("Usage: go run . [OPTION] [STRING] [BANNER]\nExample: go run . --output=<fileName.txt> something standard")
		return
	}
	option := os.Args[1]

	if strings.HasPrefix(option, "--output=") || strings.HasPrefix(option, "--output") {
		if len(os.Args) == 2 {
			fmt.Println("Usage: go run . [OPTION] [STRING] [BANNER]\nExample: go run . --output=<fileName.txt> something standard")
			return

		}
	}
	if strings.HasPrefix(option, "--output=") && strings.HasSuffix(option, ".txt") && len(option) > 13 && !strings.Contains(option, "/") {
		if len(os.Args) < 3 || len(os.Args) > 4 {
			fmt.Println("Usage: go run . [OPTION] [STRING] [BANNER]\nExample: go run . --output=<fileName.txt> something standard")
			return
		}
		xFile := os.Args[1]

		xFile = strings.TrimPrefix(xFile, "--output=")
		input := os.Args[2]
		banner := ""

		if len(os.Args) == 3 {
			banner = "standard"
		} else {
			banner = os.Args[3]
		}

		data, err := os.ReadFile("./banners/" + banner + ".txt")
		if err != nil {
			fmt.Println("Error: Failed to read standard text file:", err)
			return
		}
		strdata := string(data)
		var sliceOfFile []string

		if banner == "thinkertoy" {
			sliceOfFile = strings.Split(strdata, "\r\n")
		} else {
			sliceOfFile = strings.Split(strdata, "\n")
		}

		sliceOfInput := strings.Split(input, "\\n")

		input = strings.ReplaceAll(input, "\\n", "\n")

		if !output.Check(sliceOfInput) {
			fmt.Println("Character Not Found")
			os.Exit(2)
		}

		result := output.Print(input, sliceOfInput, sliceOfFile)

		err = os.WriteFile(xFile, []byte(result), 0o644)
		if err != nil {
			fmt.Println("error writing file: %w", err)
		}

	} else {
		if len(os.Args) < 2 || len(os.Args) > 3 {
			fmt.Println("Usage: go run .  [OPTION] [STRING] [BANNER] \nEX: go run . something standard")
			return
		}
		input := os.Args[1]
		banner := ""

		if len(os.Args) == 2 {
			banner = "standard"
		} else {
			banner = os.Args[2]
		}

		data, err := os.ReadFile("./banners/" + banner + ".txt")
		if err != nil {
			fmt.Println("Error: Failed to read standard text file:", err)
			return
		}

		strdata := string(data)
		var sliceOfFile []string

		if banner == "thinkertoy" {
			sliceOfFile = strings.Split(strdata, "\r\n")
		} else {
			sliceOfFile = strings.Split(strdata, "\n")
		}

		sliceOfInput := strings.Split(input, "\\n")

		input = strings.ReplaceAll(input, "\\n", "\n")

		if !output.Check(sliceOfInput) {
			fmt.Println("Character Not Found")
			os.Exit(2)
		}
		result := output.Print(input, sliceOfInput, sliceOfFile)
		fmt.Print(result)
	}
}
