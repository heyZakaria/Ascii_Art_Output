package output

func Check(sliceOfInput []string) bool {
	for _, word := range sliceOfInput {
		for _, char := range word {
			if int(char) < 32 || int(char) > 126 {
				return false
			}
		}
	}
	return true
}
