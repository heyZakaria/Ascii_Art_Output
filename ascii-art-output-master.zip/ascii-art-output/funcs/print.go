package output

func Print(input string, sliceOfInput []string, sliceOfFile []string) string {
	counter := 0
	var str string
	for _, word := range sliceOfInput {
		// Check and Print NewLine
		if word == "" {
			if counter < len(input) {
				str += "\n"
			}
			counter += 1
			continue
		}
		// Print Charachters line by line
		for i := 0; i < 8; i++ {
			for _, char := range word {
				pos := int(char) - 32
				line := (pos * 8) + (pos + 1)
				str += sliceOfFile[line+i]
			}
			str += "\n"
		}
		counter += len(word)
	}
	return str
}
